let timer;
let isRunning = false;
let milliseconds = 0;
let seconds = 0;
let minutes = 0;
let hours = 0;
let laps = [];

function startStop() {
    if (isRunning) {
        clearInterval(timer);
        document.getElementById("startStopBtn").textContent = "Start";
    } else {
        timer = setInterval(updateTime, 10); // Update every 10 milliseconds
        document.getElementById("startStopBtn").textContent = "Stop";
    }
    isRunning = !isRunning;
}

function reset() {
    clearInterval(timer);
    isRunning = false;
    milliseconds = 0;
    seconds = 0;
    minutes = 0;
    hours = 0;
    laps = [];
    updateDisplay();
    document.getElementById("startStopBtn").textContent = "Start";
    document.getElementById("lapList").innerHTML = "";
}

function lap() {
    laps.push(formatTime(hours, minutes, seconds, milliseconds));
    updateLapList();
}

function formatTime(hours, minutes, seconds, milliseconds) {
    return `${hours < 10 ? "0" : ""}${hours}:${minutes < 10 ? "0" : ""}${minutes}:${seconds < 10 ? "0" : ""}${seconds}:${milliseconds < 10 ? "00" : milliseconds < 100 ? "0" : ""}${milliseconds}`;
}

function updateDisplay() {
    const display = document.getElementById("display");
    display.textContent = formatTime(hours, minutes, seconds, milliseconds);
}

function updateLapList() {
    const lapList = document.getElementById("lapList");
    lapList.innerHTML = "";
    laps.forEach((lapTime, index) => {
        const lapItem = document.createElement("li");
        lapItem.textContent = `Lap ${index + 1}: ${lapTime}`;
        lapList.appendChild(lapItem);
    });
}

function updateTime() {
    milliseconds += 10;
    if (milliseconds === 1000) {
        milliseconds = 0;
        seconds++;
        if (seconds === 60) {
            seconds = 0;
            minutes++;
            if (minutes === 60) {
                minutes = 0;
                hours++;
            }
        }
    }
    updateDisplay();
}

document.getElementById("startStopBtn").addEventListener("click", startStop);
document.getElementById("resetBtn").addEventListener("click", reset);
document.getElementById("lapBtn").addEventListener("click", lap);
